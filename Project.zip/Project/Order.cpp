// #include "stdafx.h"
#include "Order.h"
#include "Order_Detail.h"
//#include"Payment.h"
//#include "Registered.h"
#include<iostream>
#include<string> 
#define SIZE 10

using namespace std;

Order::Order()     // Default constructor
{
	cout << " DEFAULT ORDER CONSTRUCTOR CALLED" << endl;
  orderId = 0;
	dateCreated = "";
	dateShipped = "";
	customerName = "";
	customerId = 0;
	status = "";
	shippingId = "";
	maxsize = 0;
	orderDetail = new Order_Detail();
	
	//Payment * payment;
}

Order::Order(int oID, string dCreated, string dShipped, string cusName, int cusId, string ostatus, string shId, int size) // overload constructor
{
	orderId = oID;
	dateCreated = dCreated;
	dateShipped = dShipped;
	customerName = cusName;
	customerId = cusId;
	status = ostatus;
	shippingId = shId;
	maxsize = size;
	orderDetail = new Order_Detail[size];
	
	//Payment * payment;
}

string Order::placeOrder() //Method
{
	return placeOrder();
}

void Order::displayOrder()
{
  cout<<"ORDER DETAILS DIPLAYED SUCCESFULLY"<<endl;
}

string Order::updateOrder()
{
	return updateOrder();
}


Order::~Order()
{
  cout<<"ORDER  DESTUCTED"<<endl;
	
}
