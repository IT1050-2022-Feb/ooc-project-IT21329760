#pragma once
#include<string>
#include "Product.h"
#define SIZE 10
using namespace std;
class Product;
class Order_Detail  // cart class
{
private:   // Attributes
	int orderId;
	int productId;
	string productName;
	int quantity;
	float unitCost;
	float subtotal;
	Product * Pro[SIZE];

public:   // methods
	Order_Detail();
	Order_Detail(int oId, int pId, string pName, int qty, float uniCost, float subT, Product * pPro);
	float calcPrice();
	~Order_Detail();
};

