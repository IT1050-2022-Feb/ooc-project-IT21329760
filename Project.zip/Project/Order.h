#pragma once
#include<string>
#include "Order_Detail.h"
#define SIZE 10
using namespace std;
class Order  // order class
{
private:   // Attributes
	int orderId;
	string dateCreated;
	string dateShipped;
	string customerName;
	int customerId;
	string status;
	string shippingId;
	int maxsize;
	Order_Detail * orderDetail;
  //Payment * payment;
	
public:    // Methods
	Order();
	Order(int oID, string dCreated, string dShipped, string cusName, int cusId, string ostatus, string shId, int size);
	string placeOrder();
	void displayOrder();
	string updateOrder();
	~Order();
};

