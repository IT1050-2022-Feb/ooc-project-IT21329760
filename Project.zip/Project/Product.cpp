// #include "stdafx.h"
#include "Product.h"
#include "Order_Detail.h"
#include<string>
#include<iostream>
using namespace std;

Product::Product()
{
	cout << " DEFAULT PRODUCT CONSTRUCTOR CALLED" << endl;
  product_ID = 0;
	productName = "";
	product_Type = "";
	weight = 0;
}

Product::Product(int pId, string pname, string pType, int pweight)
{
	product_ID = pId;
	productName = pname;
	product_Type = pType;
	weight = pweight;
	cout << "Call overload constructor" << endl;
	cout << "Product ID :" << pId << endl;
	cout << "Product Name :" << pname << endl;
	cout << "Product Type :" << pType << endl;
	cout << "Product Weight :" << pweight << endl;
	cout << endl;

}

void Product::addOrderDetail(Order_Detail * o)
{
}

void Product::filterProduct()
{
  cout<<"PRODUCTS FILTERED CORRECTLY"<<endl;
}

void Product::searchProduct()
{
  cout<<"PRODUCTS SEARCH COMPLETED"<<endl;
  
}


Product::~Product()
{
  cout<<"PRODUCT DESTUCTED"<<endl;
	
}
