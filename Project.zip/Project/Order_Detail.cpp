// #include "stdafx.h"
#include "Order_Detail.h"
#include "Product.h"
#include<iostream>
using namespace std;


Order_Detail::Order_Detail()   //default constructor
{
	cout << " DEFAULT ORDER_DETAIL CONSTRUCTOR CALLED" << endl;
  orderId = 0;
	productId = 0;
	productName ="";
	quantity = 0;
	unitCost = 0;
	subtotal = 0;
}

Order_Detail::Order_Detail(int oId, int pId, string pName, int qty, float uniCost, float subT, Product * pPro) // overload constructor
{
	orderId = oId;
	productId = pId;
	productName = pName;
	quantity = qty;
	unitCost = uniCost;
	subtotal = subT;
	Pro[0] = pPro;
	Pro[0]->addOrderDetail(this);
}

float Order_Detail::calcPrice() // method
{
	subtotal = unitCost * quantity;
	return subtotal;
  cout<<"PRICE CALCULATED "<<endl;
}


Order_Detail::~Order_Detail() //destructor
{
  cout<<"ORDER DETAILS DESTUCTED"<<endl;
}
