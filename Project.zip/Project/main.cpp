// main.cpp : Defines the entry point for the console application.
//

// #include "stdafx.h"
#include<iostream>
using namespace std;
#include "Order_Detail.h"
#include "Order.h"
#include "Product.h"

int main()
{
	Order_Detail * od1 = new Order_Detail();
	od1->calcPrice();

	Order * order1 = new Order();
	order1->displayOrder();

	Product * p1 = new Product();
	p1->filterProduct();
	p1->searchProduct();
	
	delete od1;
	delete order1;
	delete p1;

    return 0;
}

