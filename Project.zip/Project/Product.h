#pragma once
#include<string>
#include "Order_Detail.h"
#define SIZE 10
using namespace std;
class Order_Detail;
class Product
{
private:
	int product_ID;
	string productName;
	string product_Type;
	Order_Detail * orderDetail;
	int weight;

public:
	Product();
	Product(int pId, string pname, string pType, int pweight);
	void addOrderDetail(Order_Detail * o);
	void filterProduct();
	void searchProduct();

	~Product();
};

